function [parameters] = system_fetch_parameters(cfg) 
parameters = cfg.parameters.values;

