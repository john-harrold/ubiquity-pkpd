rm(list=ls())

library("deSolve")

cfile = "
/* file mymod.c */
#include <R.h>
static double parms[1];
#define k1 parms[0]

/* initializer  */
void initmod(void (* odeparms)(int *, double *))
{
    int N=1;
    odeparms(&N, parms);
}
void derivs (int *neq, double *t, double *y, double *ydot,
             double *yout, int *ip)
{
    if (ip[0] <1) error(\"nout should be at least 1\");
    ydot[0] = -k1*y[0];
    yout[0] = y[0];
}
/* END file mymod.c */
"

if(file.exists(paste("mymod", .Platform$dynlib.ext, sep = ""))){
  file.remove( paste("mymod", .Platform$dynlib.ext, sep = "")) }
if(file.exists("mymod.c")){
   file.remove("mymod.c") }
if(file.exists("mymod.o")){
   file.remove("mymod.o") }

fileConn<-file("mymod.c")
writeLines(cfile, fileConn)
close(fileConn)

system("R CMD SHLIB mymod.c")
dyn.load(paste("mymod", .Platform$dynlib.ext, sep = ""))

parms <- c(k1 = 0.04)
Y     <- c(y1 = 10.0)
times <- seq(0,10,.1)
out <- ode(Y, times, func = "derivs", parms = parms,
           dllname = "mymod",
           initfunc = "initmod", nout = 1, outnames = "Conc")



plot(out)


