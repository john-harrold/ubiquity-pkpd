#clearing the workspace
rm(list=ls())
# Turning on more verbose error reporting
options(error=traceback)
options(show.error.locations = TRUE)
# Uncomment to set the script directory as the working directory
# This works when calling this file as a script:
# R -e "source('thisfile.r')"
# setwd(dirname(sys.frame(tail(grep('source',sys.calls()),n=1))$ofile))
graphics.off()
library("deSolve")
library("ggplot2")
library("gdata")
source("library/r_general/ubiquity.r");

# Used for parallelizing 
library("foreach")
library("doParallel")
library("doRNG")
library("gridExtra")

# For documentation explaining how to modify the commands below
# See the "R Workflow" section at the link below:
# http://presentation.ubiquity.grok.tv

# Rebuilding the system (R scripts and compiling C code)
cfg = build_system(output_directory     = file.path(".", "output"),
                   temporary_directory  = file.path(".", "transient"))

# loading the different functions
source("transient/auto_rcomponents.r");

# Loading the system information
cfg = system_fetch_cfg()
# set name                  | Description
# -------------------------------------------------------
# default                   | Original Estimates

cfg = system_select_set(cfg, "default")

# fetching the parameter values
parameters = system_fetch_parameters(cfg)

dst_day    = c(c(.5, 1, 3, 5, 8, 12,  24)/24, 2, 3, 4, 5, 6, 7, 10)
doses_mpk  = c(1.0, 5.0, 10, 15, 20, 30)
blq_ng_ml  = .1 
nsub       = 10  


# The following applies to both individual and stochastic simulations:
# Define the solver to use
cfg=system_set_option(cfg,group = "simulation", option = "solver", value = "lsoda")
#
# To overwrite solver options use the following:
# cfg=system_set_option(cfg,group  = "solver",
#                           option = "atol",   
#                           value  = 1e-10)
# cfg=system_set_option(cfg,group  = "solver",
#                           option = "rtol",   
#                           value  = 1e-10)

ot = sort(unique(c(linspace(0,10,100), dst_day)*24))
# Specify the output times 
cfg=system_set_option(cfg, group  = "simulation", 
                           option = "output_times", 
                           ot)

# -------------------------------------------------------------------------
# # Stochastic Simulation:
# # To use this you need to have specified variability 
# # in your model using the <IIV:?>, <IIV:?:?>, and <IIVCOR:?:?> 
# # delimiters see examples/system-iiv.txt
#
# cfg = system_set_option(cfg, group="stochastic", option="ci",      value=95 )
  cfg = system_set_option(cfg, group="stochastic", option="nsub",    value=nsub)
# cfg = system_set_option(cfg, group="stochastic", option="ponly",   value=FALSE)
# cfg = system_set_option(cfg, group="stochastic", option="states",  value=list())
# cfg = system_set_option(cfg, group="stochastic", option="outputs", value=c('OP1', 'OP2'))
 
id   = 1
seed = 8675309
for(dose in doses_mpk){
  cfg = system_set_option(cfg, group="stochastic", option="seed", value=seed)
  cfg = system_zero_inputs(cfg) 
  cfg = system_set_bolus(cfg, state   ="Mpb", 
                              times   = c(0   ),  #  hours
                              values  = c(dose))  #  mpk

  # simulating for the current dose level 
  som   = simulate_subjects(parameters, cfg)

  # now we step through the subjects and add the relevant outputs to datasets
  for(sid in 1:nsub){
    
    # Smooth profiles
    sub_Cmblood_all = som$outputs$Cmblood[sid,]
    sub_Cpblood_all = som$outputs$Cpblood[sid,]
    time_hrs_all   = som$times$ts.hours

    sub_Cpblood_sam = approx(x = time_hrs_all, y=sub_Cpblood_all, xout=dst_day*24)$y
    sub_Cmblood_sam = approx(x = time_hrs_all, y=sub_Cmblood_all, xout=dst_day*24)$y

    # Setting the blq levels
    sub_Cmblood_sam[sub_Cmblood_sam < blq_ng_ml] = -1
    sub_Cpblood_sam[sub_Cpblood_sam < blq_ng_ml] = -1

    # storing things in a custom dataset 
    tmp_df_data = data.frame(TIME=c(dst_day*24),
                             ID  = rep(id, times=length(dst_day*24)),
                             PT  = sub_Cpblood_sam,
                             MT  = sub_Cmblood_sam,
                             BLQ = rep(blq_ng_ml, times=length(dst_day*24)),
                             DOSE= rep(dose,      times=length(dst_day*24)))

    if(exists('cust_data')){
      cust_data = rbind(cust_data, tmp_df_data)
    } else {
      cust_data = tmp_df_data
    }
    
    # storing them in a nonmem dataset
    tmp_df_nmdata = data.frame(TIME= c(0, dst_day*24, dst_day*24),
                               ID  = c(id, rep(id, times=length(dst_day*24)*2)),
                               DV  = c('.', sub_Cpblood_sam, sub_Cmblood_sam),
                               EVID= c(1,    rep(0  , times=length(dst_day*24)*2)), 
                               CMT = c(1,    rep(1  , times=length(dst_day*24)), rep(2  , times=length(dst_day*24))),
                               AMT = c(dose, rep('.', times=length(dst_day*24)*2)), 
                               RATE= c('.',  rep('.', times=length(dst_day*24)*2)), 
                               BLQ = c(blq_ng_ml, rep(blq_ng_ml, times=length(dst_day*24)*2)),
                               DOSE= c(dose, rep(dose,      times=length(dst_day*24)*2)))

    if(exists('nm_data')){
      nm_data = rbind(  nm_data, tmp_df_nmdata)
    } else {
      nm_data = tmp_df_nmdata
    }

    id = id + 1
  }

  pp = ggplot() 
  pp = pp + geom_point(data=cust_data[cust_data$DOSE == dose, ], aes(TIME, PT), color='blue')
  pp = pp + geom_line( data=som$tcsummary, aes(x=ts.hours, y=o.Cpblood.median), color='red' ,  linetype='solid', size=0.9) 
  pp = gg_log10_yaxis(fo=pp)
  pp = prepare_figure('present', pp)              

  pm = ggplot() 
  pm = pm + geom_point(data=cust_data[cust_data$DOSE == dose, ], aes(TIME, MT), color='blue')
  pm = pm + geom_line( data=som$tcsummary, aes(x=ts.hours, y=o.Cmblood.median), color='red' ,  linetype='solid', size=0.9) 
  pm = gg_log10_yaxis(fo=pm)
  pm = prepare_figure('present', pm)              
  

  grb = grid.arrange(pp, pm)
  ggsave(file.path('output', sprintf('generate_data-dose_%d.pdf', dose)), grb)

  # changing the seed
  seed = seed + 1

}

# making sure it's all sorted correclty
nm_data = nm_data[with(nm_data, order(ID, TIME, -EVID)), ]
# writing the data in nonmem format to a file:
write.csv(x=nm_data, file='nm_data.csv', quote=FALSE, row.names=FALSE)
