#clearing the workspace
rm(list=ls())
graphics.off()
options(show.error.locations = TRUE)

# if we are in a stand alone distribution we run from there
# otherwise we try to load the package
if(file.exists(file.path('library', 'r_general', 'ubiquity.R'))){
  source(file.path('library', 'r_general', 'ubiquity.R'))
} else { 
  library(ubiquity) }

# Rebuilding the system (R scripts and compiling C code)
cfg = build_system(output_directory     = file.path(".", "output"),
                   temporary_directory  = file.path(".", "transient"))


# set name   | Description
# -------------------------------------------------------
# default    | mAb in Humans
# Selecting the default paraemter set
cfg = system_select_set(cfg, 'default')

# Fetching the parameter values
parameters = system_fetch_parameters(cfg)

# To overwrite the default dosing uncomment
cfg = system_zero_inputs(cfg)
cfg = system_set_bolus(cfg, state = "At",
                           times  = c(  0.0,  14.0,  28.0),
                           values = c(400.0, 400.0, 400.0))


# The following applies to both individual and stochastic simulations:
# Define the solver to use
cfg=system_set_option(cfg,group   = "simulation",
                          option  = "solver",
                          value   = "lsoda")

# Specify the output times 
cfg=system_set_option(cfg, group  = "simulation",
                           option = "output_times",
                           value  = seq(0,80,.1))
# -------------------------------------------------------------------------
# # Stochastic Simulation:
cfg=system_set_option(cfg, group  = "stochastic",
                           option = "nsub",
                           value  = 200)
                           
cfg=system_set_option(cfg, group  = "stochastic",
                           option = "ponly",
                           value  = TRUE)

# Uncomment the following to parallelize the simulations
# library("doParallel")
# cfg=system_set_option(cfg, group  = "simulation",
#                            option = "parallel",    
#                            value  = "multicore")
# 
# cfg=system_set_option(cfg, group  = "simulation",
#                            option = "compute_cores", 
#                            value  = detectCores() - 1)
  
som  = simulate_subjects(parameters, cfg)
sexs = c(0,1)

set.seed(8675309)

for(subidx in c(1:length(som$subjects$parameters[,1]))){

   # Pulling out the current set of parameters
   # and dropping  MW
   PARAMS = som$subjects$parameters[subidx,]
   PARAMS = subset(PARAMS, select = -c(MW))

   # Adding subid and time
   SI = data.frame(
      SIMINT_ID   = subidx,
      SIMINT_TIME = 0)
   # Adding covariates
   COV = data.frame(
      WT  = round(runif(1, min=30, max=75), digits=1), 
      SEX = sample(c(0,1),1))


  # Subject row
  CSUB = cbind(SI, PARAMS, COV)

  # Building the subject dataframe
  if(subidx == 1){
    SUBS = CSUB
  }
  else { SUBS = rbind(SUBS, CSUB)}

}

 write.csv(SUBS, 'mab_pk_subjects.csv', row.names=FALSE)

