#
#
#
my_model <- function() {
ini({<SYSTEM_PARAMS_TV><IIV_DEF><IIV_BLOCK><ERROR_PARAMS>
})
model({ <SYSTEM_PARAMS><SSP><DSP><RINF><ODES><OUTPUTS>
})
}
