clear; close all;

% setting up paths
provision_workspace;

build_system

% pulling out the system information
cfg           = auto_fetch_system_information();
% fetching the default parameter values
parameters    = cfg.parameters.values;

% running the simulation
simout_mapped = simulation_driver(parameters, cfg);

% The following code can be used to plot all of the defined outputs

plot_handles  = [];
legend_labels = [];
close all;
figure(1);
hold on;

plot(simout_mapped.times.sim_time, simout_mapped.outputs.Cpblood); 
plot(simout_mapped.times.sim_time, simout_mapped.outputs.Cmblood); 



% Common post plotting options, uncomment as necessary
ylabel('outputs');
xlabel('time');
axis tight;
