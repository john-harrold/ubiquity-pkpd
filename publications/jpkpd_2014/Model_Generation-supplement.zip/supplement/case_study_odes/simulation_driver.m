function[simout_mapped]=simulation_driver(parameters, cfg)

% The for loop will create a variable for each parameter automatically in this workspace
for parameter_idx = 1:length(parameters)
  eval(sprintf('%s = parameters(parameter_idx);',char(cfg.parameters.names(parameter_idx))));
end

% The commented lines will do the same thing more explicitly and provide examples
% of how to access each parameter from the numerical 'parameters' vector


%  Kp          = parameters(cfg.options.mi.parameters.Kp); 
%  Vp          = parameters(cfg.options.mi.parameters.Vp); 
%  K12         = parameters(cfg.options.mi.parameters.K12); 
%  K21         = parameters(cfg.options.mi.parameters.K21); 
%  Km          = parameters(cfg.options.mi.parameters.Km); 
%  Vm_fm       = parameters(cfg.options.mi.parameters.Vm_fm); 


% Here are the static secondary parameters
% The following 'if' and 'for' chunks will create the secondary parameters
% in an automated fashion.  Similar to the parameters, the explicit declarations
% are made below (more for reference than anything)

if(isfield(cfg.options.misc, 'static_secondary_parameters'))
  static_secondary_parameters = fieldnames(cfg.options.misc.static_secondary_parameters);
  for parameter_idx = 1:length(static_secondary_parameters)
    eval(sprintf('%s = %s;', ...
             char(static_secondary_parameters(parameter_idx)), ...
         getfield(cfg.options.misc.static_secondary_parameters,char(static_secondary_parameters(parameter_idx)))));
  end 
end 



% Setting up the simulation options
simulation_options.model_name    = 'ode_simulation';
simulation_options.default_simopts.Solver = 'ode23s';



% First set the default initial condition to be zero for all states 
simulation_options.initialstate  = zeros(1,length(fieldnames(cfg.options.mi.states)));
% To force matlab to use simulink uncomment the following line:
% simulation_options.integrate_with = 'simulink';
% To include things like bolus times in the sampled output uncomment
% the following line:
% simulation_options.include_important_output_times = 'yes';
%
% Next we overwrite those states that are nonzero 
% The following 'if' and 'for' chunks will define the initial conditions
% components of the simulation_options for the states that have non-zero
% initial conditions. This is done in an  automated fashion.  Similar 
% to the parameters, the explicit declarations are made below 
% (again for reference)
if(isfield(cfg.options, 'initial_conditions'))
  initial_conditions          = fieldnames(cfg.options.initial_conditions);
  for state_idx = 1:length(initial_conditions)
    eval(sprintf('simulation_options.initialstate(cfg.options.mi.states.%s) = %s;', ...
             char(initial_conditions(state_idx)), ...
         getfield(cfg.options.initial_conditions,char(initial_conditions(state_idx)))));
  end 
end 



% No bolus inputs were specified



% Defining infusion rates
simulation_options.infusion_rates(1).name        = 'infusion';
simulation_options.infusion_rates(1).levels(1,:) = [  0  1]*1 ;% time 
simulation_options.infusion_rates(1).levels(2,:) = [100  0]*1;% mass/time



% No time varying inputs were specified
 simulation_options.output_times    = linspace(0,100,1000)';

% running the simulation
[simout]=run_simulation_generic(parameters, simulation_options);
% mapping the outputs and states
simout_mapped = auto_map_simulation_output(simout);
