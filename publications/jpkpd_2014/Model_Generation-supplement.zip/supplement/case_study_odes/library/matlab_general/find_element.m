function [elnumber]=find_element(cellarr, stringid)
% function [elnumber]=find_element(cellarr, stringid)
%
%  This function takes the one dimensional cell array (cellarr) and looks at
%  each element to see if it is the same as stringid and returns the element
%  number corresponding to that vlaue. 
%
%  This is used to determine the row or column number which correpsonds to a
%  specific value. 
%
%  elnumber will have a value of -1 if no solution was found
%
%  Note: Any spaces at the beginning or end of the elements of cellarr are
%  ignored, but the search is case sensitve.
%
%  Example: the following cell array contains a table of information about
%  three groups. Say you want clearance values for group 2. You can access
%  this value by looking at mydata(3,2). But it is undesirable to hard code
%  those values, a better way is to do the following:
%
%  mydata = [{'group'}  {'CL'} {'Vc'} {'Fb'}
%            {'  g1 '}   .21     75     .5
%            {' g2'}     .32     54     .7
%            {' g3 '}    .45     63     .2];
%
%
% % all of the rows in the first column
% tmp_row = find_element(mydata(:,1), 'g2');
%
%
% % all of the columns in the first row
% tmp_col = find_element(mydata(1,:), 'CL');
%
% mydata(tmp_row,tmp_col)
%



  elnumber    = -1;
   % stripping any extra whitespace at the beginning or end of the string
   stringid = regexprep(stringid, '^\s*', ''); % beginning white space
   stringid = regexprep(stringid, '\s*$', ''); % end       white space

  for arr_idx = 1:length(cellarr)
      tmpstr = char(cellarr(arr_idx));
      % stripping any extra whitespace at the beginning or end of the string
      tmpstr = regexprep(tmpstr, '^\s*', ''); % beginning white space
      tmpstr = regexprep(tmpstr, '\s*$', ''); % end       white space
      % now we check to see if the strings match
      if(strcmp(tmpstr, stringid))
        elnumber = arr_idx ;
      end

  end
