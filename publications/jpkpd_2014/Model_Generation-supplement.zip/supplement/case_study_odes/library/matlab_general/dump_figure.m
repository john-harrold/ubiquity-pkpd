function []=dump_figure(filename)
%
% Places the currently opened figure in 'filename'.
%
%    -> If you're on a mac it will create 'filename.pdf
%    -> If you're on windows it will create 'filename.tif'
%


if(ismac)
  eval(sprintf('export_fig %s -transparent -pdf',  filename));
  try
    eval(sprintf('export_fig %s -transparent -png', filename));
  end
elseif(ispc) 
  eval(sprintf('export_fig %s -transparent -tiff', filename));
end
