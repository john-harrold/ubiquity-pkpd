function []=generate_report(parameters, solution_stats, cfg)
% function []=generate_report(parameters, solution_stats, cfg)
%
%   parameters     -- vector of parameter estimates from fminsearch
%   solution_stats -- output of solution_statistics.m
%   cfg            -- variable with parameter field defined
%
%   creates file 'report.txt' with summary information from analysis
%


OFH = fopen('report.txt', 'w');

% Start
% Dumping Estimates, confidence interval
%


fprintf(OFH, '         Estimate     95 %% Confidence Interval        Coeff. of Var\n');
fprintf(OFH, '                      Lower Bound    Upper Bound       (Percent) \n');


for i=1:length(parameters)
  fprintf(OFH, '%s', pad_string(char(cfg.estimation.parameters.names(i)), 10));
  fprintf(OFH, '%s', var2string(parameters(i), 12));
  fprintf(OFH, '%s', var2string(solution_stats.confidence_interval.lower_bound(i),15));
  fprintf(OFH, '%s', var2string(solution_stats.confidence_interval.upper_bound(i),15));
  fprintf(OFH, '%s', var2string(solution_stats.coefficient_of_variation(i),15));
  fprintf(OFH, '\n');
end
%
% Dumping Estimates, confidence interval, etc.
% End

    fprintf(OFH, '\n\n\n');

% Start
% Dumping the covariance matrix
%
fprintf(OFH, '%s', pad_string('', 10));
fprintf(OFH, 'Variance -- Covariance Matrix \n');

fprintf(OFH, '%s', pad_string('', 10));
for i=1:length(parameters)
    fprintf(OFH, '%s', pad_string(sprintf('%s    ',char(cfg.estimation.parameters.names(i))), 12));
end
    fprintf(OFH, '\n');

for i=1:length(parameters)
    fprintf(OFH, '%s', pad_string(char(cfg.estimation.parameters.names(i)), 10));
for j=1:length(parameters)
    if(j<=i)
    fprintf(OFH, '%s', var2string(solution_stats.covariance(i,j),12));
    end
end
    fprintf(OFH, '\n');
end
%
% Dumping the covariance matrix
% End

fprintf(OFH, '\n\n\n');
fprintf(OFH, 'Misc Information \n');
fprintf(OFH, 'OBJ = %.6f\n',solution_stats.objective);
fprintf(OFH, 'AIC = %.6f\n',solution_stats.aic);
fprintf(OFH, 'BIC = %.6f\n',solution_stats.bic);



%fprintf(OFH, sprintf('                  & LB & Value & UB \\\\\\\\  \\\\hline   \\\\hline  \n'));
%i=1; fprintf(OFH, sprintf('\\\\verb|%s| &$%s$& $%s$  &$%s$\\\\\\\\',...
                  %char(cfg.parameters.names(i)), ...
                  %var2latex(solution_stats.confidence_interval.lower_bound(i), '%.3f'), ...
                  %var2latex(parameters(i),                                     '%.3f'), ...
                  %var2latex(solution_stats.confidence_interval.upper_bound(i), '%.3f')));

fclose(OFH);
