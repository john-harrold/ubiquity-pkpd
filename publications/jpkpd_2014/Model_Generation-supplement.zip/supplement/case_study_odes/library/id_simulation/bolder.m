h=gca;
set(h,'Fontsize',14);
set(h,'linewidth',1.5);
set(get(gca,'children'),'linewidth',1.5);
