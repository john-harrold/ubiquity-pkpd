
clear; close all;
build_system;
% setting up paths
provision_workspace;

% pulling out the system information
cfg = fetch_cfg;

% pulling the default parameter set:
parameters = cfg.parameters.sets.default.values;
so = simulation_driver(parameters, cfg);
tissue_names = cfg.options.tissues;
figure(1);
set(gcf, 'Position',  [18 12 677 744]);
for tissue_idx = 1:length(tissue_names)
  tissue = tissue_names{tissue_idx}; 

  % pulling out the adapt simulation 
  % data for the current tissue

  % pulling out the current simulation 
  % data for the current tissue

  current.time = so.times.hours;
  eval(sprintf('current.conc = so.outputs.C_TOT_nM_%s;', tissue));

  eval(sprintf('animal_data.time = cfg.mouse_data.%s.data.time;', tissue))
  eval(sprintf('animal_data.conc = cfg.mouse_data.%s.data.conc;', tissue))
  
  subplot(5,2, tissue_idx); hold on;
  set(gca, 'yscale', 'log');
  set(gca, 'ytick', [1 10 100 1000]);
  set(gca, 'yticklabel', {'1' '10' '100' '1000'});
  ylim([1 1500])

  hdata  = plot(animal_data.time,  animal_data.conc, 'o');
  hnew   = plot(current.time,      current.conc  , 'b--');

  text(20, 2, tissue, 'interpreter', 'none');
  if(tissue_idx ==  8)
    legend(hdata,  {'Data'}, 'location', 'southeast');
    legend boxoff;
  end
  if(tissue_idx ==  10)
    legend(hnew ,  {'New Implementation'}, 'location', 'southeast');
    legend boxoff;
  end


  prepare_figure('present');

  if(mod(tissue_idx,2) == 0)
    set(gca, 'yaxislocation', 'right');
  end
  if(tissue_idx == 5 | tissue_idx == 6)
    ylabel('Conc (nM)');
  end

  if(tissue_idx <= 8)
    set(gca, 'xticklabel', []);
  else
    xlabel('time (hours)');
  end
  

end
%eval(sprintf('export_fig output%sQC_profiles -transparent -pdf', filesep));
