provision_workspace;
clear; close all;
cfg = fetch_cfg;
% pulling the default parameter set:


flow_names  = [{'BCQ'}, {'PLQ'}]';

pset_names = fieldnames(cfg.options.mi.parameter_sets);
p_names    = fieldnames(cfg.options.mi.parameters);

disp('% ------------------------------------- ');
disp('% For each parameter set we compare the ');
disp('% blood cell flow rates (BCQ) and plasma');
disp('% flow rates (PLQ) leaving the organs   ');
disp('% to those entering the lung to make    ');
disp('% sure they balance out                 ');
disp('% ------------------------------------- ');
for pset_idx = 1:length(pset_names)
  current_set = pset_names{pset_idx};
  eval(sprintf('current_parameters = cfg.parameters.sets.%s.values;', current_set));
  eval(sprintf('current_set_name   = cfg.parameters.sets.%s.name;',   current_set));
  disp(sprintf('processing ->%s<-', current_set_name));
  for flow_idx = 1:length(flow_names)
    current_flow = flow_names{flow_idx};
    flow_total   = 0;
    flow_lung    = 0;

    for p_idx = 1:length(p_names)
      current_parameter = p_names{p_idx};
      if(regexp(current_parameter, current_flow))
        if(regexp(current_parameter, 'LUNG'))
          flow_lung = current_parameters(p_idx);
        else
          flow_total = flow_total + current_parameters(p_idx);
        end
      end
    end
    flow_diff = flow_total - flow_lung;
    disp(sprintf(' %s:      Organs - Lung        ->%.3e<-', current_flow,  flow_diff));
  end
end

