function [cfg]=fetch_cfg()

% pulling up the system information
cfg = auto_fetch_system_information;

% pulling in the validation data
datasets = {'PLASMA'
            'LUNG'
            'HEART' 
            'KIDNEY'
            'MUSCLE'
            'SKIN'
            'LG_INT'
            'SPLEEN'
            'SM_INT'
            'LIVER'};

cfg.options.tissues = datasets;

mouse_datafile = sprintf('data%smouse_validation_data.xls', filesep);

%
% Loading the simulation output from ADAPT for the mouse
%
cfg.mouse_data = {};

warning off;
for ds_idx = 1:length(datasets)
    ds = datasets{ds_idx};

    % loading  data
    try
      clear tmp_ds;
      tmp_sheet_name   = sprintf('%s_DATA',ds);
      tmp_sheet_data   = cell2mat(fetch_excel_raw(mouse_datafile, tmp_sheet_name));
      tmp_ds.data.time = tmp_sheet_data(:,1);
      tmp_ds.data.conc = tmp_sheet_data(:,2);
      cfg.mouse_data = setfield(cfg.mouse_data, ds, tmp_ds);
    end

end

cfg.options.output_times  = [linspace(0,10,500), linspace(11,300,1000)];
cfg.options.dosing.times  = 0; % days
cfg.options.dosing.values = 8.0; % mg/kg
