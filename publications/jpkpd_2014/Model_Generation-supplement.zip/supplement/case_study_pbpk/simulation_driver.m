function [simout_mapped] = simulation_driver(parameters, cfg)


% The for loop will create a variable for each parameter automatically in this workspace
for parameter_idx = 1:length(parameters)
  eval(sprintf('%s = parameters(parameter_idx);',char(cfg.parameters.names(parameter_idx))));
end


% Here are the static secondary parameters
% The following 'if' and 'for' chunks will create the secondary parameters
% in an automated fashion.  Similar to the parameters, the explicit declarations
% are made below (more for reference than anything)

if(isfield(cfg.options.misc, 'static_secondary_parameters'))
  static_secondary_parameters = fieldnames(cfg.options.misc.static_secondary_parameters);
  for parameter_idx = 1:length(static_secondary_parameters)
    eval(sprintf('%s = %s;', ...
             char(static_secondary_parameters(parameter_idx)), ...
         getfield(cfg.options.misc.static_secondary_parameters,char(static_secondary_parameters(parameter_idx)))));
  end 
end 


% Setting up the simulation options
simulation_options.model_name    = 'ode_simulation';
simulation_options.default_simopts.Solver = 'ode15s' ;



% First set the default initial condition to be zero for all states 
simulation_options.initialstate  = zeros(1,length(fieldnames(cfg.options.mi.states)));
% To force matlab to use simulink uncomment the following line:
% simulation_options.integrate_with = 'simulink';
% To include things like bolus times in the sampled output uncomment
% the following line:
simulation_options.include_important_output_times = 'yes';
%
% Next we overwrite those states that are nonzero 
% The following 'if' and 'for' chunks will define the initial conditions
% components of the simulation_options for the states that have non-zero
% initial conditions. This is done in an  automated fashion.  Similar 
% to the parameters, the explicit declarations are made below 
% (again for reference)
if(isfield(cfg.options.misc, 'static_secondary_parameters'))
  initial_conditions          = fieldnames(cfg.options.initial_conditions);
  for state_idx = 1:length(initial_conditions)
    eval(sprintf('simulation_options.initialstate(cfg.options.mi.states.%s) = %s;', ...
             char(initial_conditions(state_idx)), ...
         getfield(cfg.options.initial_conditions,char(initial_conditions(state_idx)))));
  end 
end 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_LUNG)   = FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_OTHER)  = FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_LG_INT) = FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_BRAIN)  = FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_BONE)   = FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_THYMUS) = FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_KIDNEY) = FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_MUSCLE) = FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_SPLEEN) = FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_SKIN)   = FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_SM_INT) = FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_HEART)  = FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_PANCREAS)= FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_ADIPOSE)= FCRN_0; 
% simulation_options.initialstate(cfg.options.mi.states.FCRN_LIVER)  = FCRN_0; 


% Setting up bolus events
bolus_times = cfg.options.dosing.times.*24.0; % day 
simulation_options.bolus_inputs(1,:) = bolus_times;
simulation_options.bolus_inputs(2,:) = cfg.options.dosing.values.*BW*6.6667e-9/V_TOT_PLASMA;% mg/kg
simulation_options.bolus_inputs(3,:) = ones(size(bolus_times)).*cfg.options.mi.states.C_PLASMA;
 


% No time varying inputs were specified
 simulation_options.output_times    = cfg.options.output_times;

% running the simulation
[simout]=run_simulation_generic(parameters, simulation_options);
simout_mapped = auto_map_simulation_output(simout);
