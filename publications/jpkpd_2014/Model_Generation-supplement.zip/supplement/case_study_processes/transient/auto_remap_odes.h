dx[0] = SIMINT_dCp; 
dx[1] = SIMINT_dR; 
dx[2] = SIMINT_dCp_R; 
dx[3] = SIMINT_dCt; 
dx[4] = SIMINT_dBM; 
