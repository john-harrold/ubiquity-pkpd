 y[0] =1.0 - R/(R+Cp_R);
 y[1] =BM;
