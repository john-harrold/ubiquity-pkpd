/* Internal Variables */
double SIMINT_TIME = 0.0;
/* Initializing parameters */
double CL          = 0.0; 
double Q           = 0.0; 
double Vp          = 0.0; 
double Vt          = 0.0; 
double koff        = 0.0; 
double KD          = 0.0; 
double R_IC        = 0.0; 
double kdegR       = 0.0; 
double BM_IC       = 0.0; 
double kdegBM      = 0.0; 
double Imax        = 0.0; 
double IC50        = 0.0; 



/* Initializing derivatives  */
double SIMINT_dCp   = 0.0; 
double SIMINT_dR    = 0.0; 
double SIMINT_dCp_R = 0.0; 
double SIMINT_dCt   = 0.0; 
double SIMINT_dBM   = 0.0; 



 /* Initializing dynamic secondary paramters */
double ktp         = 0.0; 
double kpt         = 0.0; 
double kel         = 0.0; 
double kon         = 0.0; 
double ksynR       = 0.0; 
double ksynBM      = 0.0; 



/* Mapping states to their common names */
double Cp           = 0.0;
double R            = 0.0;
double Cp_R         = 0.0;
double Ct           = 0.0;
double BM           = 0.0;



 /* Defining dynamic secondary paramters */
double STIM        = 0.0;



/* Defining internal values */
SIMINT_TIME = ssGetT(S);



/* 
 * Mapping C inputs to variable names and 
 * defining secondary parameters  
 */


/* Defining parameters */
CL          = u[0]; 
Q           = u[1]; 
Vp          = u[2]; 
Vt          = u[3]; 
koff        = u[4]; 
KD          = u[5]; 
R_IC        = u[6]; 
kdegR       = u[7]; 
BM_IC       = u[8]; 
kdegBM      = u[9]; 
Imax        = u[10]; 
IC50        = u[11]; 



 /* Defining static secondary paramters */
ktp         =Q/Vt; 
kpt         =Q/Vp; 
kel         =CL/Vp; 
kon         =koff/KD; 
ksynR       =kdegR*R_IC*Vp; 
ksynBM      =kdegBM*BM_IC; 



/* Mapping states to their common names */
Cp           = x[0];
R            = x[1];
Cp_R         = x[2];
Ct           = x[3];
BM           = x[4];



 /* Defining dynamic secondary paramters */
STIM        = 1.0+Imax*Cp_R/(IC50+Cp_R);
