SIMINT_dCp    = koff*Cp_R            + ktp*Ct*Vt/Vp        
              - kon*Cp*R             - kpt*Cp              
           + (-kel*Cp);
SIMINT_dR     = koff*Cp_R            + ksynR/Vp            
              - kon*Cp*R             - kdegR*R             ;
SIMINT_dCp_R  = kon*Cp*R            
              - koff*Cp_R           
           + (-kdegR*Cp_R);
SIMINT_dCt    = kpt*Cp*Vp/Vt        
              - ktp*Ct              ;
SIMINT_dBM    = ksynBM*STIM         
              - kdegBM*BM           ;
