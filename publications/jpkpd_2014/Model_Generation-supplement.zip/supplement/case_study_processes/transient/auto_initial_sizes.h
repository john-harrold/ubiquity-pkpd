
ssSetNumContStates(    S, 5);  
ssSetNumInputs(        S, 12);  
ssSetNumOutputs(       S, 2);  
ssSetNumDiscStates(    S, 0);
ssSetDirectFeedThrough(S, 1);
ssSetNumSampleTimes(   S, 1);
ssSetNumSFcnParams(    S, 0);
ssSetNumRWork(         S, 0);
ssSetNumIWork(         S, 0);
ssSetNumPWork(         S, 0);
