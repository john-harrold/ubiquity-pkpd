clear; close all;

build_system;

% setting up paths
provision_workspace;

% pulling out the system information
cfg        = auto_fetch_system_information();
% fetching the default parameter values
parameters = cfg.parameters.values;

% The for loop will create a variable for each parameter automatically in this workspace
for parameter_idx = 1:length(parameters)
  eval(sprintf('%s = parameters(parameter_idx);',char(cfg.parameters.names(parameter_idx))));
end

% The commented lines will do the same thing more explicitly and provide examples
% of how to access each parameter from the numerical 'parameters' vector


%  CL          = parameters(cfg.options.mi.parameters.CL); 
%  Q           = parameters(cfg.options.mi.parameters.Q); 
%  Vp          = parameters(cfg.options.mi.parameters.Vp); 
%  Vt          = parameters(cfg.options.mi.parameters.Vt); 
%  koff        = parameters(cfg.options.mi.parameters.koff); 
%  KD          = parameters(cfg.options.mi.parameters.KD); 
%  R0          = parameters(cfg.options.mi.parameters.R0); 
%  kdeg        = parameters(cfg.options.mi.parameters.kdeg); 


% Here are the static secondary parameters
% The following 'if' and 'for' chunks will create the secondary parameters
% in an automated fashion.  Similar to the parameters, the explicit declarations
% are made below (more for reference than anything)

if(isfield(cfg.options.misc, 'static_secondary_parameters'))
  static_secondary_parameters = fieldnames(cfg.options.misc.static_secondary_parameters);
  for parameter_idx = 1:length(static_secondary_parameters)
    eval(sprintf('%s = %s;', ...
             char(static_secondary_parameters(parameter_idx)), ...
         getfield(cfg.options.misc.static_secondary_parameters,char(static_secondary_parameters(parameter_idx)))));
  end 
end 
%  ktp         = Q/Vt;
%  kpt         = Q/Vp;
%  kel         = CL/Vp;
%  kon         = koff/KD;
%  ksynR       = kdeg*R0*Vp;



% Setting up the simulation options
simulation_options.model_name    = 'ode_simulation';
simulation_options.default_simopts.Solver = 'ode23s';



% First set the default initial condition to be zero for all states 
simulation_options.initialstate  = zeros(1,length(fieldnames(cfg.options.mi.states)));
% To force matlab to use simulink uncomment the following line:
% simulation_options.integrate_with = 'simulink';
% To include things like bolus times in the sampled output uncomment
% the following line:
% simulation_options.include_important_output_times = 'yes';
%
% Next we overwrite those states that are nonzero 
% The following 'if' and 'for' chunks will define the initial conditions
% components of the simulation_options for the states that have non-zero
% initial conditions. This is done in an  automated fashion.  Similar 
% to the parameters, the explicit declarations are made below 
% (again for reference)
if(isfield(cfg.options, 'initial_conditions'))
  initial_conditions          = fieldnames(cfg.options.initial_conditions);
  for state_idx = 1:length(initial_conditions)
    eval(sprintf('simulation_options.initialstate(cfg.options.mi.states.%s) = %s;', ...
             char(initial_conditions(state_idx)), ...
         getfield(cfg.options.initial_conditions,char(initial_conditions(state_idx)))));
  end 
end 
% simulation_options.initialstate(cfg.options.mi.states.R)           = R0; 



% Setting up bolus events
bolus_times = [ 0].*24*7; % weeks 
simulation_options.bolus_inputs(1,:) = bolus_times;
simulation_options.bolus_inputs(2,:) = [50].*7.143/Vp;% mg
simulation_options.bolus_inputs(3,:) = ones(size(bolus_times)).*cfg.options.mi.states.Cp;



% No infusion rates were specified



% No time varying inputs were specified
 simulation_options.output_times    = linspace(-10,10*7*24,1000)';

% running the simulation
[simout]=run_simulation_generic(parameters, simulation_options);
% mapping the outputs and states
simout_mapped = auto_map_simulation_output(simout);

% The following code can be used to plot all of the defined outputs

plot_handles  = [];
legend_labels = [];
close all;
figure(1);
hold on;

 plot(simout_mapped.times.weeks, simout_mapped.outputs.Occupancy); 
 plot(simout_mapped.times.weeks, simout_mapped.outputs.BM_Stim); 



% Common post plotting options, uncomment as necessary
  ylabel('outputs');
  xlabel('time (weeks)');
  axis tight;
  set(gca, 'yscale', 'log');
  prepare_figure('present');
