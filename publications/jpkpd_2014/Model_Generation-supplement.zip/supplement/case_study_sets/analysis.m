clear; close all;
% compiling the system to make sure the 
% latest changes have been committed. 
build_system

% setting up paths
provision_workspace;

% pulling out the system information
cfg  = auto_fetch_system_information();

% selecting the default paramter set:
cfg  = select_set(cfg, 'default');

%cfg.estimation.observation_function = 'observation_details';
%cfg.estimation.objective_type       = 'wls';

% fetching the parameter values
parameters = cfg.parameters.values;

% The previous statement sets 'parameters' to the default
% values specified in system.txt. To overwrite a specific 
% parameter uncomment the following statement and replace 
% PNAME with the name of the parameter and VALUE with the
% desired value:
%
% parameters(cfg.options.mi.parameters.PNAME) = VALUE;



% No bolus inputs were specified



% No infusion rates were specified



% Evaluate system at the following output times
cfg.options.simulation_options.output_times = linspace(0,10,1000)';


% Options to control simulation execution and outputs are defined here.
%
% To force matlab to use simulink uncomment the following line:
% cfg.options.simulation_options.integrate_with = 'simulink';
%
% To include things like bolus times in the sampled output uncomment
% the following line:
% cfg.options.simulation_options.include_important_output_times = 'yes';
%
% To change the ODE sovler that is used:
% cfg.options.simulation_options.default_simopts.Solver = 'ode23s';

% Simulating the system and storing the result in  som (Simulation Output
% Mapped) -- a data structure with times, states and outputs mapped to 
% their internal names
som = run_simulation_ubiquity(parameters, cfg);


% the following just plots all of the 
% specified outputs
figure(1);
hold on;
figure(1);
hold on;

output_names = fieldnames(som.outputs);

for output_idx = 1:length(output_names)
  current_output  = getfield(som.outputs, output_names{output_idx});
  plot(som.times.sim_time, current_output)
end

prepare_figure('present');
  set(gca, 'yscale', 'log');
  xlabel('time');
  ylabel('outputs');

